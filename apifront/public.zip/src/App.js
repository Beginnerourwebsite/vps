import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Createcolumn from './Createcolumn'

export default function App() {
  return (
    <div>
        <BrowserRouter>
        <Routes>
            <Route path='/' element={<Createcolumn/>}/>
        </Routes>
        </BrowserRouter>
    </div>
  )
}
