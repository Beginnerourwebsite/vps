import React from 'react'
import "../style/css.css"
export default function Common(prop) {

    return (
        <div style={{ display: "flex", justifyContent: "center" }}>
            <div id='commonfirstdiv'>
                <h1 style={{ fontSize: "50px" }}>Main Information</h1>
                <input type="search" placeholder='Host (Double Click for Option)' list='lists' name="" id="" />
                <datalist id='lists'>
                    <option value="localhost">localhost</option>
                    <option aria-readonly value="Online">Online</option>
                </datalist>

                <div>
                    <input type="text" placeholder='userName' name="" id="" />
                    <input type="text" name="" placeholder='passWord' id="" />
                </div>
                <div>

                    <input type="text" name="" placeholder='DataBase Name' id="" />
                    <input type="text" name="" placeholder='Table Name' id="" />
                </div>
                <input type="checkbox" name="" id="Checksaveornot" /><label htmlFor="Checksaveornot">Save Details</label>
                <br />
                <button id='fullTable' onClick={prop.click}>Table check</button>
                <button >next</button>
            </div>
        </div>
    )
}
